package terrain;

public class Vue {
Terrain terrain;
public Vue(Terrain t){
this.terrain=terrain;	
}
}
