package parcelle;
import terrain.Coordonnees;
public class Parcelle {

int trou;
boolean mur;
boolean tas;
Coordonnees cord;
Taupe taupe;

public Parcelle(int x,int y){
this.cord= new Coordonnees(x,y);	
}

public Coordonnees getCoordonnees(){
	return this.cord;
}

public void setCoordonnees(Coordonnees c){
	this.cord.modifier(c);
}

public int  estTrou(){
	return this.trou;
}

public void setTrou(int x){
	this.trou=x;
}

public boolean estMur(){
	return this.mur;
}

public boolean estTas(){
	return this.tas;
}

public int estTaupe(){
	if(this.taupe==null)return 0;
	return this.taupe.getEquipe();
}

public void setMur(){
	this.mur=true;
}

	
}
