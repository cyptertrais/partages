package parcelle;

public class Trou extends Parcelle{

	public Trou(int x,int y,int equipe){
	super(x,y);	
	super.setTrou(equipe);
	}
}
