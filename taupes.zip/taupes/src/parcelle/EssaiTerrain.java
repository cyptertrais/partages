package parcelle;

import terrain.Terrain;

public class EssaiTerrain {

	public static void main(String[] args) {
		
		Terrain terrain = new Terrain(20);

	}

}
