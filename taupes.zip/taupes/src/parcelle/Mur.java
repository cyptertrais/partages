package parcelle;

public class Mur extends Parcelle{

	public Mur(int x,int y){
		super(x,y);
		setMur();
	}
}
