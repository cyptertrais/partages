package parcelle;

public class Tas extends Parcelle{

	public Tas(int x,int y){
		super(x,y);
	}
}
