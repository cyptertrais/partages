package personnages.abstrait;

import java.util.Random;

public interface Vivant {
 static final Random ALEA= new Random();
 public void attaque(Vivant v);
 public void subitattaque(Vivant v);
 public void perte(int vie);
 public int getforce();
 public boolean estvivant();
}
