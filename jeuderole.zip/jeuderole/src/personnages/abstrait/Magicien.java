package personnages.abstrait;

import personnages.concret.Arme;
import personnages.concret.Element;

public interface Magicien extends Vivant {
	
	public void attaque(Magicien  c);
	public Arme getArme();
	public Element getElement();
	
}
