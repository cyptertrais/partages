package personnages.abstrait;

public abstract class Personnage implements Vivant {

	private String nom;
	private int vie;
	private int force;
	private static int nbPersonnages;
	private int numeroPersonnages;
	
	
	public Personnage(){
		this.nom=nbPersonnages+"";
		nbPersonnages++;
	}
	
	public Personnage(String nom){
		nbPersonnages++;
		this.vie=100;this.nom=nom;this.force=10;
		
	}
	@Override
	public abstract void attaque(Vivant v);

	@Override
	public abstract void subitattaque(Vivant v);

	@Override
	public void perte(int vie) {
		this.vie=this.vie-vie;
		
	}

	@Override
	public int getforce() {
		return force;
	}
	
	

	public int getForce() {
		return force;
	}

	public void setForce(int force) {
		this.force = force;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public void setVie(int vie) {
		this.vie = vie;
	}

	public static void setNbPersonnages(int nbPersonnages) {
		Personnage.nbPersonnages = nbPersonnages;
	}

	public void setNumeroPersonnages(int numeroPersonnages) {
		this.numeroPersonnages = numeroPersonnages;
	}

	@Override
	public boolean estvivant() {
	return this.vie>0;
	}

}
