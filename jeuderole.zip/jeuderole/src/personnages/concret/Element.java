package personnages.concret;

public enum Element {
EAU(Element.values()[1]),FEU(Element.values()[0]),TERRE(Element.values()[3]),AIR(Element.values()[3]);
private Element  opose ;


	
	private Element(Element opose){
		this.opose=opose;
		}
	
	public boolean estOppose(Element element){
		return this.opose.equals(element.opose);
	}
	public Element getOpose(Element e){
		return e.opose;
	}
	
}
