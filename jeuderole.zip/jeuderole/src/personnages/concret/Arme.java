package personnages.concret;

public enum Arme {
ARC(1),EPEE(2),HACHE(3);
private int puissance ;


	
	private Arme(int power){
		puissance=power;
		}
	
	public int getPuissance(){return this.puissance;}
	
}
