package personnages.concret;
import personnages.abstrait.*;


public class Guerrier extends Personnage implements Combattant{
private Arme arme;
	public Guerrier(){
		super();
		this.arme=Arme.values()[Vivant.ALEA.nextInt(Arme.values().length)];
		this.setNumeroPersonnages(1);
		
		
		
	}
	public Guerrier(String nom){
		super();
		super.setNom(nom);
		this.arme=Arme.values()[Vivant.ALEA.nextInt(Arme.values().length)];
		this.setNumeroPersonnages(1);
	}
	public Guerrier(String nom,Arme arme){
		super();
		super.setNom(nom);
		this.arme=arme;
		this.setNumeroPersonnages(1);
	}

	public void subitattaque(Vivant v) {
		if(v instanceof Combattant){
			if((((Combattant) v).getArme().getPuissance()!=(this.arme.getPuissance()))){
				this.perte(v.getforce()*(((Combattant) v).getArme().getPuissance()));
			}else{
				this.perte(v.getforce());
			}
			
			
		}
		if(v instanceof Magicien){
			this.perte(getforce());
		}
		
		
	}



	@Override
	public Arme getArme() {
		// TODO Auto-generated method stub
		return arme;
	}
	@Override
	public void attaque(Combattant c) {
		c.subitattaque(this);
		this.setForce(getForce()+1);
		
	}
	@Override
	public void attaque(Vivant v) {
		v.subitattaque(this);
		this.setForce(getForce()+1);
		
	}

	
}
