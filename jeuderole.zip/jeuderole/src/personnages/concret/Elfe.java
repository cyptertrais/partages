package personnages.concret;

import personnages.abstrait.Combattant;
import personnages.abstrait.Magicien;
import personnages.abstrait.Personnage;
import personnages.abstrait.Vivant;

public class Elfe extends Personnage implements Combattant,Magicien{

	@Override
	public void attaque(Magicien c) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Element getElement() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void attaque(Combattant c) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Arme getArme() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void attaque(Vivant v) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void subitattaque(Vivant v) {
		// TODO Auto-generated method stub
		
	}

}
